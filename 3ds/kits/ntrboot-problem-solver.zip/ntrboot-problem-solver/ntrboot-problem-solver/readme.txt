This starter kit is intended for people who have a pre-flashed flashcart that is ready to perform the NTRboot exploit. The contents of this kit should be copied to the console's SD card.
This starter kit should only be used with NH's guide: https://3ds.hacks.guide/ntrboot
This starter kit is current as of January 2nd 2021.
If the date is more than a month after the currency date, there is a good chance this kit is outdated in some way.
Check the guide to get the latest files.

!!! boot.firm is the SafeB9Sinstaller. Once you have used it to install b9s successfully, you should delete it, and move boot.firm from the /luma folder onto the root folder. Your device will only boot to SafeB9Sinstaller until you do this. !!!