# Atmosphère Cheats 

### A 
|Name|TitleID|Region
|--|--|--
|A Hole New World|[01000060085D2000](01000060085D2000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO 3 COUNT BOUT|[0100FC000AFC6000](0100FC000AFC6000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO AERO FIGHTERS 2|[0100AC40038F4000](0100AC40038F4000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO AERO FIGHTERS 3|[0100B91008780000](0100B91008780000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO AGGRESSORS OF DARK KOMBAT|[0100B4800AFBA000](0100B4800AFBA000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO ALPHA MISSION II|[0100A76002B46000](0100A76002B46000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO ART OF FIGHTING|[01006A80038FC000](01006A80038FC000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO ART OF FIGHTING 2|[010066600877E000](010066600877E000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO ART OF FIGHTING 3|[01004AC002B40000](01004AC002B40000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO BLAZING STAR|[0100DFC003398000](0100DFC003398000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO BLUE'S JOURNEY|[0100379003900000](0100379003900000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO BURNING FIGHT|[01002AA004DB4000](01002AA004DB4000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO CROSSED SWORDS|[0100D2400AFB0000](0100D2400AFB0000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO CYBER-LIP|[010082200AFBE000](010082200AFBE000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO FATAL FURY|[0100EE6002B48000](0100EE6002B48000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO FATAL FURY 3|[01000D1008714000](01000D1008714000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO FATAL FURY SPECIAL|[010019A0038FA000](010019A0038FA000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO GAROU: MARK OF THE WOLVES|[0100CB2001DB8000](0100CB2001DB8000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO GHOST PILOTS|[01005D700A2F8000](01005D700A2F8000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO KARNOV'S REVENGE|[010014E004FA8000](010014E004FA8000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO MAGICIAN LORD|[01007920038F6000](01007920038F6000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO METAL SLUG|[0100EBE002B3E000](0100EBE002B3E000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO METAL SLUG 2|[010086300486E000](010086300486E000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO METAL SLUG 3|[0100BA8001DC6000](0100BA8001DC6000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO METAL SLUG 4|[01009CE00AFAE000](01009CE00AFAE000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO METAL SLUG 5|[01004C000AFDC000](01004C000AFDC000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO METAL SLUG X|[01008FD004DB6000](01008FD004DB6000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO MUTATION NATION|[01007F4004FA4000](01007F4004FA4000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO NAM-1975|[0100A8C001DCE000](0100A8C001DCE000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO NINJA COMBAT|[010052A00A306000](010052A00A306000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO NINJA COMMANDO|[01007E800AFB6000](01007E800AFB6000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO PREHISTORIC ISLE 2|[0100A7800AFAA000](0100A7800AFAA000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO REAL BOUT FATAL FURY|[010030F008730000](010030F008730000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO REAL BOUT FATAL FURY 2|[0100CF3008798000](0100CF3008798000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO RIDING HERO|[01002C900A302000](01002C900A302000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO ROBO ARMY|[01000C9004FA2000](01000C9004FA2000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO SAMURAI SHODOWN IV|[010047F001DBC000](010047F001DBC000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO SAMURAI SHODOWN V|[01000C800AFD6000](01000C800AFD6000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO SENGOKU|[0100D170038EA000](0100D170038EA000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO SENGOKU 2|[01009B300872A000](01009B300872A000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO SENGOKU 3|[01008D000877C000](01008D000877C000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO THE KING OF FIGHTERS '94|[0100EB2001DCC000](0100EB2001DCC000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO THE KING OF FIGHTERS '95|[01009DC001DB6000](01009DC001DB6000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO THE KING OF FIGHTERS '96|[01006F0004FB4000](01006F0004FB4000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO THE KING OF FIGHTERS '97|[0100170008728000](0100170008728000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO THE KING OF FIGHTERS '98|[0100B42001DB4000](0100B42001DB4000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO THE KING OF FIGHTERS '99|[0100583001DCA000](0100583001DCA000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO THE KING OF FIGHTERS 2000|[0100B97002B44000](0100B97002B44000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO THE KING OF FIGHTERS 2001|[010048200AFC2000](010048200AFC2000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO THE KING OF FIGHTERS 2002|[0100CFD00AFDE000](0100CFD00AFDE000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO THE KING OF FIGHTERS 2003|[0100EF100AFE6000](0100EF100AFE6000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO THE SUPER SPY|[0100F7F00AFA2000](0100F7F00AFA2000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO TWINKLE STAR SPRITES|[0100B8300AFD8000](0100B8300AFD8000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO WAKU WAKU 7|[0100CEF001DC0000](0100CEF001DC0000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO WORLD HEROES 2|[01001BD00915A000](01001BD00915A000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO WORLD HEROES 2 JET|[01006C3004FAE000](01006C3004FAE000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO WORLD HEROES PERFECT|[01009D4001DC4000](01009D4001DC4000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ACA NEOGEO ZED BLADE|[01005AF004DBC000](01005AF004DBC000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|ARMS Demo|[01009B500007C000](01009B500007C000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|AngerForce: Reloaded|[010001E00A5F6000](010001E00A5F6000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Arcade Archives DOUBLE DRAGON|[0100F25001DD0000](0100F25001DD0000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Arcade Archives DOUBLE DRAGON II|[01009E3001DDE000](01009E3001DDE000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Asterix & Obelix XXL 2|[010050400BD38000](010050400BD38000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Atelier Totori ~The Adventurer of Arland~ DX|[01009BC00C6F6000](01009BC00C6F6000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### B 
|Name|TitleID|Region
|--|--|--
|BLAZBLUE CENTRALFICTION Special Edition|[0100EE900AB58000](0100EE900AB58000/cheats)|![JPN](http://nswdb.com/images/JPN.jpg)
|BLAZBLUE CROSS TAG BATTLE|[0100B61008208000](0100B61008208000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Battle Cats|[01003C300B274000](01003C300B274000/cheats)|![JPN](https://nswdb.com/images/JPG.jpg)
|Bayonetta™|[010076F0049A2000](010076F0049A2000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Bayonetta™ 2|[01007960049A0000](01007960049A0000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Beyblade Burst: Battle Zero|[010068600AD16000](010068600AD16000/cheats)|![JPN](http://nswdb.com/images/JPN.jpg)
|Blade Arcus Rebellion From Shining|[0100C4400CB7C000](0100C4400CB7C000/cheats)|![JPN](http://nswdb.com/images/JPN.jpg)
|Blaster Master Zero Demo|[0100225000FEE000](0100225000FEE000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Bleed|[010042C006490000](010042C006490000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Bleed 2|[0100A48008AE8000](0100A48008AE8000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Bloodstained: Curse of the Moon|[01004B800AF5A000](01004B800AF5A000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Blossom Tales: The Sleeping King|[0100C1000706C000](0100C1000706C000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Blue Rider|[01006A600B5E6000](01006A600B5E6000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### C 
|Name|TitleID|Region
|--|--|--
|Captain Toad: Treasure Tracker|[01009BF0072D4000](01009BF0072D4000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Cartoon Network: Battle Crashers|[0100085003A2A000](0100085003A2A000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Cat Quest|[0100A2F006FBE000](0100A2F006FBE000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Cave Story+|[0100A55003B5C000](0100A55003B5C000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Cave Story+|[0100B7D0022EE000](0100B7D0022EE000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Chasm|[0100DE200C350000](0100DE200C350000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Chocobo's Mystery Dungeon EVERY BUDDY!|[0100BF600BF26000](0100BF600BF26000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Crash Bandicoot™ N. Sane Trilogy|[0100D1B006744000](0100D1B006744000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Cuphead|[0100A5C00D162000](0100A5C00D162000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Cursed Castilla|[0100ED700B376000](0100ED700B376000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### D 
|Name|TitleID|Region
|--|--|--
|DRAGON BALL FIGHTERZ|[0100A250097F0000](0100A250097F0000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|DRAGON BALL XENOVERSE 2 for Nintendo Switch|[010078D000F88000](010078D000F88000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Dark Souls™: Remastered|[01004AB00A260000](01004AB00A260000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Darksiders Warmastered Edition|[0100E1400BA96000](0100E1400BA96000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Dead Cells|[0100646009FBE000](0100646009FBE000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Dead Cells|[0100FC000AEF0000](0100FC000AEF0000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Dragon Blaze for Nintendo Switch|[010099B00A2DC000](010099B00A2DC000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Dragon Marked for Death: Frontline Fighters|[010089700150E000](010089700150E000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Dragon Quest Builders 2|[010050000705E000](010050000705E000/cheats)|![JPN](http://nswdb.com/images/JPN.jpg)
|Dragon Quest® Builders™|[010008900705C000](010008900705C000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Dusty Raging Fist|[010097D00402C000](010097D00402C000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### E 
|Name|TitleID|Region
|--|--|--
|Elliot Quest|[0100128003A24000](0100128003A24000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### F 
|Name|TitleID|Region
|--|--|--
|FINAL FANTASY IX|[01007EF00B094000](01007EF00B094000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|FINAL FANTASY X/X-2 HD Remaster|[0100BC300CB48000](0100BC300CB48000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|FINAL FANTASY XII THE ZODIAC AGE|[0100EB100AB42000](0100EB100AB42000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Final Fantasy X X-2 HD Remaster|[0100FE500D0CA000](0100FE500D0CA000/cheats)|![CHN](http://nswdb.com/images/CHN.jpg)
|Fire Emblem Warriors™|[0100F15003E64000](0100F15003E64000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Fitness Boxing|[0100E7300AAD4000](0100E7300AAD4000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### G 
|Name|TitleID|Region
|--|--|--
|GODS Remastered|[0100BAA00AE16000](0100BAA00AE16000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|GUNBIRD for Nintendo Switch|[01003C6008940000](01003C6008940000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|GUNBIRD2 for Nintendo Switch|[0100BCB00AE98000](0100BCB00AE98000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|GhoulBoy|[0100A9500C606000](0100A9500C606000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Gigantic Army|[010067A00D35E000](010067A00D35E000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Goken|[0100126006EF0000](0100126006EF0000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Golf Story|[0100779004172000](0100779004172000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Guacamelee! 2|[01007E100456C000](01007E100456C000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### H 
|Name|TitleID|Region
|--|--|--
|Hollow Knight|[0100633007D48000](0100633007D48000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Hyrule Warriors: Definitive Edition|[0100AE00096EA000](0100AE00096EA000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### I 
|Name|TitleID|Region
|--|--|--
|Iconoclasts|[0100BC60099FE000](0100BC60099FE000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### J 
|Name|TitleID|Region
|--|--|--
|Just Dance 2018®|[0100A0500348A000](0100A0500348A000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Just Dance® 2019|[010075600AE96000](010075600AE96000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### K 
|Name|TitleID|Region
|--|--|--
|KAMIKO|[010085300314E000](010085300314E000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Kero Blaster|[0100DA200A09A000](0100DA200A09A000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### L 
|Name|TitleID|Region
|--|--|--
|Little Inferno|[0100B18001D8E000](0100B18001D8E000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### M 
|Name|TitleID|Region
|--|--|--
|Mario Kart™ 8 Deluxe|[0100152000022000](0100152000022000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Mario Tennis™ Aces|[0100BDE00862A000](0100BDE00862A000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Mega Man 11 Demo|[0100B0C0086B0000](0100B0C0086B0000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Mega Man Legacy Collection|[01002D4007AE0000](01002D4007AE0000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Mega Man X Legacy Collection|[01005C60086BE000](01005C60086BE000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Monkey King: Master of the Clouds|[01004C500B8E0000](01004C500B8E0000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Monster Boy and the Cursed Kingdom|[01006F7001D10000](01006F7001D10000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Mortal Kombat 11|[0100F2200C984000](0100F2200C984000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### N 
|Name|TitleID|Region
|--|--|--
|NBA 2K Playgrounds 2|[01001AE00C1B2000](01001AE00C1B2000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Neko Navy Daydream Edition|[0100E5500B020800](0100E5500B020800/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|New Super Mario Bros. U Deluxe|[0100EA80032EA000](0100EA80032EA000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Nickelodeon Kart Racers|[0100D6200933C000](0100D6200933C000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Nightmare Boy|[01005F4009112000](01005F4009112000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### O 
|Name|TitleID|Region
|--|--|--
|OKAMI HD|[0100276009872000](0100276009872000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Oceanhorn - Monster of Uncharted Seas|[01007D7001D0E000](01007D7001D0E000/cheats)|![USA](http://nswdb.com/images/USA.jpg)
|Octopath Traveler™|[010057D006492000](010057D006492000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Okami HD|[0100F10009870000](0100F10009870000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|One Piece: Unlimited World Red - Deluxe Edition|[0100574002AF4000](0100574002AF4000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Onimusha: Warlords|[0100416008A12000](0100416008A12000/cheats)|![JPN](http://nswdb.com/images/JPN.jpg)
### P 
|Name|TitleID|Region
|--|--|--
|Peach Ball Senran Kagura W Pack ver|[010082500350E000](010082500350E000/cheats)|![JPN](http://nswdb.com/images/JPN.jpg)
|Pokken Tournament DX|[0100B3F000BE2000](0100B3F000BE2000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Pokémon: Let's Go, Eevee!|[0100187003A36000](0100187003A36000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Pokémon: Let's Go, Pikachu!|[010003F003A34000](010003F003A34000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Pro Yakyuu Famista Evolution|[01008EA0080F6000](01008EA0080F6000/cheats)|![JPN](http://nswdb.com/images/JPN.jpg)
|Project Highrise: Architect's Edition|[0100BBD00976C000](0100BBD00976C000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### R 
|Name|TitleID|Region
|--|--|--
|Rad Rodgers Radical Edition|[010000600CD54000](010000600CD54000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Resident Evil|[010050F00BC1A000](010050F00BC1A000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Resident Evil Revelations|[0100643002136000](0100643002136000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|River City Girls|[01004E700DFE6000](01004E700DFE6000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### S 
|Name|TitleID|Region
|--|--|--
|STRIKERS1945 for Nintendo Switch|[0100FF5005B76000](0100FF5005B76000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|STRIKERS1945 Ⅱ for Nintendo Switch|[0100720008ED2000](0100720008ED2000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|SUPER DRAGON BALL HEROES WORLD MISSION - Launch Edition|[0100E5E00C464000](0100E5E00C464000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Samurai Aces for Nintendo Switch™|[0100ADF0096F2000](0100ADF0096F2000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Senjou no Valkyria 4|[0100C11009378000](0100C11009378000/cheats)|![JPN](http://nswdb.com/images/JPN.jpg)
|Shovel Knight: Specter of Torment|[01001180021FA000](01001180021FA000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Shovel Knight: Treasure Trove|[010057D0021E8000](010057D0021E8000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Sky Force Anniversary|[010083100B5CA000](010083100B5CA000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Sky Force Reloaded|[01006FE005B6E000](01006FE005B6E000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Sonic Mania|[01009AA000FAA000](01009AA000FAA000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Splatoon™ 2|[0100F8F0000A2000](0100F8F0000A2000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Stardew Valley|[0100E65002BB8000](0100E65002BB8000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Super Bomberman R|[01007AD00013E000](01007AD00013E000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Super Mario Odyssey™|[0100000000010000](0100000000010000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Super Robot Wars T|[01006C900CC60000](01006C900CC60000/cheats)|![CHN](http://nswdb.com/images/CHN.jpg)
|Super Smash Bros. Ultimate|[01006A800016E000](01006A800016E000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Super Toy Cars|[0100384009344000](0100384009344000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### T 
|Name|TitleID|Region
|--|--|--
|TENGAI for Nintendo Switch|[0100B2600A398000](0100B2600A398000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Tales of Vesperia: Definitive Edition|[01002C0008E52000](01002C0008E52000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|The Binding of Isaac: Afterbirth+|[010021C000B6A000](010021C000B6A000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|The Legend of Zelda™: Breath of the Wild|[01007EF00011E000](01007EF00011E000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|The Messenger|[0100DC300AC78000](0100DC300AC78000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|The World Ends With You® -Final Remix-|[0100C1500B82E000](0100C1500B82E000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Tiny Barbarian DX|[0100D940022F6000](0100D940022F6000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Titan Quest|[0100605008268000](0100605008268000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Toki|[0100F3400A432000](0100F3400A432000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### U 
|Name|TitleID|Region
|--|--|--
|Ultra Street Fighter® II: The Final Challengers|[01007330027EE000](01007330027EE000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Undertale|[010080B00AD66000](010080B00AD66000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### V 
|Name|TitleID|Region
|--|--|--
|Valkyria Chronicles 4 Demo|[01005C600AC68000](01005C600AC68000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### W 
|Name|TitleID|Region
|--|--|--
|Warriors Orochi 4|[010016A00AEC0000](010016A00AEC0000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Wonder Boy: The Dragon's Trap|[0100A6300150C000](0100A6300150C000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### X 
|Name|TitleID|Region
|--|--|--
|Xenoblade Chronicles 2: Torna ~ The Golden Country|[0100C9F009F7A000](0100C9F009F7A000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Xenoblade Chronicles™ 2|[0100E95004038000](0100E95004038000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### Y 
|Name|TitleID|Region
|--|--|--
|Yet Another Zombie Defense HD|[010085500B29A000](010085500B29A000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Yoshi's Crafted World|[01006000040C2000](01006000040C2000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
|Yoshi's Crafted World|[0100AE800C9C6000](0100AE800C9C6000/cheats)|![WLD](http://nswdb.com/images/WLD.jpg)
### Z 
|Name|TitleID|Region
|--|--|--
|Zoids Wild: King of Blast|[0100E43009320000](0100E43009320000/cheats)|![JPN](http://nswdb.com/images/JPN.jpg)
